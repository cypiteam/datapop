from django.shortcuts import render,HttpResponse
#from .models import employee_details
import os

def about(request):
	return render (request,'about.html')

def home(request):
	return HttpResponse("hello world")
def button(request):
	return render(request,'about.html')

def shutdown(request):
	a = os.system("shutdown /s /t 1")
	return render (request,'about.html',{'blogs':a})




