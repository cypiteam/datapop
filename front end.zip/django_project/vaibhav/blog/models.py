from django.db import models

# Create your models here.

class employee_details(models.Model):
	snc=models.IntegerField()
	name=models.CharField(max_length=255)
    