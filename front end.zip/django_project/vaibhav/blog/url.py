from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from . import views

urlpatterns = [
    path('home/', views.home,name='blog-home'),
    path('about/', views.about,name='blog-about'),
    url(r'^admin/', admin.site.urls),
    url(r'^$', views.button),
    # url(r'^output', views.output,name="script"),
]

